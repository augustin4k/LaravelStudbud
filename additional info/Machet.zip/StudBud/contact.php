<html>
<?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<link rel="stylesheet" href="/StudBud/css/contact.css">

<body class="bg-light"> <?php include "/xampp/htdocs/StudBud/components/header-no-log.php" ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <form action="" class="card rounded">
                    <div class="text-center card-header image-contact-header">
                        <i class="fa-solid fa-pen fa-2x"></i>
                        <h3 class="text-center">Contactează-ne</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating"> <input type="text" placeholder="Numele" class="form-control"> <label for="">Numele si prenumele</label> </div>
                                <div class="separator mb-3"></div>
                                <div class="form-floating"> <input type="email" placeholder="Email de contact" class="form-control"> <label for="">Email-ul de contact</label> </div>
                                <div class="separator mb-3"></div>
                                <div class="form-floating"> <input type="text" placeholder="Subiectul" class="form-control"> <label for="">Subiectul</label> </div>
                                <div class="separator mb-3"></div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-floating h-100">
                                    <textarea class="form-control" placeholder="Mesajul" name="" id="" rows="5"></textarea>
                                    <label for="">Mesajul</label>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-end">
                        <button class="btn btn-primary">
                            Trimite
                            <i class="fa fa-paper-plane" aria-hidden="true"></i>
                        </button>

                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php include "/xampp/htdocs/StudBud/components/footer.php" ?>
</body>

</html>