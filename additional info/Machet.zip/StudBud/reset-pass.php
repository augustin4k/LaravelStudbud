<html>
<?php include '/xampp/htdocs/StudBud/components/head.php'; ?>

<body class="bg-light">
    <?php include '/xampp/htdocs/StudBud/components/header-no-log.php'; ?>
    <div class="alert alert-primary" role="alert">
        <strong>Email-ul pentru resetarea parolei a fost trimis!</strong>
    </div>
    <form action="#" class="form-signin">
        {{-- @if (session('status')) --}}
        {{-- @endif --}}
        <div class="text-center"> <i class="mb-4 fa fa-graduation-cap fa-4x" aria-hidden="true"></i>
            <h1 class="h3 mb-3 font-weight-normal">Resetare parola</h1>
        </div>
        <div class="form-floating"> <input type="email" class="form-control" id="floatingInput"
                placeholder="name@example.com" required> <label for="floatingInput">Email address</label> </div>
        <div class="mb-3"> <small class=""><a href="index.php" class="">Ti-ai
                    amintit parola?</a></small> </div> <button class="w-100 btn btn-lg btn-primary" type="submit">
            Resetare</button>
    </form>
    <?php include '/xampp/htdocs/StudBud/components/footer.php'; ?>
</body>

</html>
