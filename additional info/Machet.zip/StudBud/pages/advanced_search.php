<html>
<?php include "/xampp/htdocs/StudBud/components/head.php" ?>

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>
    <div class="container-lg mt-1 my-lg-3">
        <div class="row">
            <div class="col-4 col-lg-4 col-xl-3 d-none d-lg-block position-relative">
                <div class="sticky-top">
                    <?php include "/xampp/htdocs/StudBud/components/nav-left.php" ?>
                </div>
            </div>
            <div class="col-12 col-lg-8 col-xl-9 main">
                <div class="row">
                    <div class="col-12 col-md-8 left-wrapper">
                        <div class="mb-3 card">
                            <div class="card-header d-flex gap-2">
                                <!-- <div class="form-group d-flex align-items-center gap-2"> -->
                                <label for="adv_search" class="d-none d-md-flex align-items-center fw-bold form-label m-0 text-secondary">Cautare:</label>

                                <div class="w-auto d-md-none d-inline">
                                    <!-- Button trigger modal -->
                                    <button class="btn btn-dark hstack gap-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasFiltruAdvanced" aria-controls="offcanvasFiltruAdvanced">
                                        <i class="bi bi-funnel-fill"></i> <span class=""><small class="fw-bold">Filtru</small></span>
                                    </button>

                                    <!-- Modal -->
                                    <div class="offcanvas offcanvas-bottom col-12 col-sm-10 offset-sm-1" tabindex="-1" id="offcanvasFiltruAdvanced" aria-labelledby="offcanvasFiltruAdvancedLabel">
                                        <div class="offcanvas-header text-secondary bg-light">
                                            <div class="d-flex align-items-center gap-2">
                                                <i class="bi bi-funnel-fill"></i>
                                                <p class="modal-title"><b>Filtru</b></p>
                                            </div>
                                            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                        </div>
                                        <div class="offcanvas-body px-0">
                                            <?php filtru_advanced(); ?>
                                        </div>
                                        <div class="card-footer text-end">
                                            <button class="btn btn-dark">Filter</button>
                                        </div>
                                    </div>
                                </div>

                                <input name="adv_search" type="text" class="form-control form-control-sm" placeholder="Introdu persoana...">
                                <!-- </div> -->
                                <button class="btn btn-secondary"><i class="bi bi-search"></i></button>
                            </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <div class="row">
                                        <?php for ($i = 0; $i < 10; $i++) : ?>
                                            <div class="col-12 col-sm-6 col-lg-12 col-xl-6 mb-2">
                                                <li class="border-0 border-bottom list-group-item px-0">
                                                    <?php prieten_item_list(); ?>
                                                </li>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="d-none d-md-block col-12 col-md-4 right-wrapper">
                        <div class="card mb-3">
                            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                <b>Filtru</b>
                                <i class="bi bi-funnel-fill"></i>
                            </div>
                            <?php function filtru_advanced()
                            { ?>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <label for=""><small>Sorteaza dupa:</small></label>
                                        <select class="form-select form-select-sm" id="">
                                            <option selected>Nr prieteni comuni - Asc</option>
                                            <option>Nr prieteni comuni - Desc</option>
                                        </select>
                                    </li>
                                    <li class="list-group-item">
                                        <label for=""><small>Tipul user-ului:</small></label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="studenti">
                                            <label class="form-check-label" for="studenti">
                                                <small>Studenti</small>
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="profesori">
                                            <label class="form-check-label" for="profesori">
                                                <small>Profesori</small>
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="universitati">
                                            <label class="form-check-label" for="universitati">
                                                <small>Universitati</small>
                                            </label>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <label for=""><small>Universitatile:</small></label>
                                            <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-universitati"> <i class="bi bi-caret-down-fill"></i> </button>
                                        </div>
                                        <div class="collapse" id="collapse-universitati">
                                            <?php for ($i = 1; $i < 6; $i++) : ?>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="<?php echo $i; ?>-universitatea">
                                                    <label class="form-check-label" for="<?php echo $i; ?>-stele">
                                                        <small>Lorem ipsum dolor sit amet.</small>
                                                    </label>
                                                </div>
                                            <?php endfor; ?>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <label for=""><small>Tara user-ului:</small></label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Moldova">
                                            <label class="form-check-label" for="Moldova">
                                                <small>R. Moldova</small>
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Romania">
                                            <label class="form-check-label" for="Romania">
                                                <small>Romania</small>
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Armenia">
                                            <label class="form-check-label" for="Armenia">
                                                <small>Armenia</small>
                                            </label>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <label for=""><small>Orasul user-ului:</small></label>
                                            <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-orase-user"> <i class="bi bi-caret-down-fill"></i> </button>
                                        </div>
                                        <div class="collapse" id="collapse-orase-user">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="oras1">
                                                <label class="form-check-label" for="oras1">
                                                    <small>Lorem ipsum dolor sit.</small>
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="oras2">
                                                <label class="form-check-label" for="oras2">
                                                    <small>Lorem ipsum dolor sit.</small>
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="oras3">
                                                <label class="form-check-label" for="oras3">
                                                    <small>Lorem, ipsum dolor.</small>
                                                </label>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            <?php };
                            filtru_advanced(); ?>
                            <div class="card-footer d-flex justify-content-end">
                                <div>
                                    <button class="btn btn-dark">Filter</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>