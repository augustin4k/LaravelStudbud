<html> <?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<!-- custom css -->
<link href="/StudBud//css/chat.css" rel="stylesheet">
<!-- js -->
<script src="/StudBud/js/chat.js"></script>

<body class="bg-light d-flex flex-column body_of_chat">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>
    <div class="container-lg chat-container mt-1 mt-lg-3">
        <div class="row">
            <div class="col-4 col-lg-4 col-xl-3 d-none d-lg-block position-relative">
                <div class="sticky-top">
                    <?php include "/xampp/htdocs/StudBud/components/nav-left.php" ?>
                </div>
            </div>
            <div class="col-12 col-lg-8 col-xl-9 main">
                <div class="clearfix row chat-app flex-row-reverse">
                    <div class="d-none d-md-block d-lg-none d-xl-inline col-12 col-md-4 left-wrapper position-relative">
                        <div id="plist " class="people-list">
                            <?php function person_list()
                            { ?>
                                <div class="card bg-white h-100 overflow-auto">
                                    <div class="card-header">
                                        <input type="text" class="form-control" placeholder="Search...">
                                    </div>
                                    <div class="card-body">
                                        <div class="list-group list-group-flush chat-list" id="">
                                            <!-- <a href="#" class="list-group-item list-group-item-action"> <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">
                                                <div class="about">
                                                    <div class="name">Stoica Eugeniu</div>
                                                    <div class="status"> <i class="fa fa-circle offline"></i><small class="text-muted"> left 7 mins ago</small></div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action active"> <img src="https://bootdey.com/img/Content/avatar/avatar2.png" alt="avatar">
                                                <div class="about">
                                                    <div class="name">Botoi Adrian</div>
                                                    <div class="status"> <i class="fa fa-circle online"></i> <small class="text-muted">online</small></div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action"> <img src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="avatar">
                                                <div class="about">
                                                    <div class="name">Cumpana Dumitru</div>
                                                    <div class="status"> <i class="fa fa-circle online"></i> <small class="text-muted">online</small></div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">
                                                <div class="about">
                                                    <div class="name">Christian Kelly</div>
                                                    <div class="status"> <i class="fa fa-circle offline"></i><small class="text-muted"> left 10 hours ago</small></div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action"> <img class="" src="https://bootdey.com/img/Content/avatar/avatar8.png" alt="avatar">
                                                <div class="about">
                                                    <div class="name">Monica Ward</div>
                                                    <div class="status"> <i class="fa fa-circle online"></i> <small class="text-muted">online</small></div>
                                                </div>
                                            </a> -->
                                            <a href="#" class="list-group-item rounded list-group-item-action">
                                                <div class="hstack align-items-center gap-1">
                                                    <img src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="avatar">
                                                    <div class="about ">
                                                        <div class="name">Dean Henry</div>
                                                        <div class="status"> <i class="fa fa-circle online"></i><small class=""> offline since Oct 28</small></div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item rounded list-group-item-action active">
                                                <div class="hstack align-items-center gap-1">
                                                    <img src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="avatar">
                                                    <div class="about ">
                                                        <div class="name">Dean Henry</div>
                                                        <div class="status"> <i class="fa fa-circle offline"></i><small class=""> offline since Oct 28</small></div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php };
                            person_list(); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-8 col-lg-12 col-xl-8 right-wrapper">
                        <div class="card chat">

                            <div class="card-header chat-header d-flex justify-content-between align-items-center">
                                <div class="d-flex justify-content-between">
                                    <div class="d-flex flex-row align-item-center">

                                        <button class="d-block d-md-none d-lg-inline d-xl-none btn btn-lg btn-secondary me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#people-list-canvas" aria-controls="people-list-canvas">
                                            <i class="fa fa-bars fa-1x" aria-hidden="true"></i>
                                        </button>

                                        <div class="offcanvas offcanvas-start border w-75" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="people-list-canvas" aria-labelledby="people-list-canvasLabel">
                                            <div class="bg-light offcanvas-header">
                                                <h5 class="m-0 text-secondary offcanvas-title" id="offcanvasLabel">Lista conversatii</h5>
                                                <button type="button" class="btn-lg btn-secondary btn" data-bs-dismiss="offcanvas" aria-label="Close">
                                                    <i class="fa fa-bars fa-1x" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                            <div class="offcanvas-body p-0">
                                                <?php person_list(); ?>
                                            </div>
                                        </div>

                                        <a href="javascript:void(0);" class="d-flex align-items-center me-1" data-toggle="modal" data-target="#view_info"> <img src="https://bootdey.com/img/Content/avatar/avatar2.png" alt="avatar"> </a>
                                        <div class="chat-about">
                                            <h6 class="mb-0">Botoi Adrian</h6> <small class="text-muted">Last seen: 2 hours ago</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="hidden-sm text-right" id="menu_chat">
                                    <div class="btn-group dropleft"> <a href="javascript:void(0);" class="btn btn-outline-secondary" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </a>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#"> <i class="fa-solid fa-user"></i> Viziteaza profilul</a>
                                            <a class="dropdown-item" href="#">
                                                <i class="fa-solid fa-image"></i>
                                                Vezi imaginile</a>
                                            <a class="dropdown-item" href="#"> <i class="fa fa-lock" aria-hidden="true"></i> Blocheaza </a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-danger" href="#"> <i class="fa fa-trash" aria-hidden="true"></i> Sterge conversatia</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body small chat-history overflow-auto" id="chat_history">
                                <ul class="mb-0 list-unstyled chat_list_messages">
                                    <li class="clearfix">
                                        <div class="float-end text-end">
                                            <div class="message-data text-end"> <span class="message-data-time">10:10 AM, Today</span>
                                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">
                                            </div>
                                            <div class="message other-message"> Hi Bsotoi, how are you? How is the project coming along?
                                                <div class="d-flex flex-wrap gap-2">
                                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar" width="100px">
                                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar" width="100px">
                                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar" width="100px"> -->
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <?php for ($i = 0; $i < 10; $i++) : ?>
                                        <li class="clearfix">
                                            <div class="message-data">
                                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">
                                                <span class="message-data-time">10:15 AM, Today</span>
                                            </div>
                                            <div class="message my-message">Project has been already finished and I have results to show you.</div>
                                        </li>
                                    <?php endfor; ?>
                                </ul>
                            </div>
                            <div class="card-footer chat-message clearfix">
                                <div class="d-flex gap-2">
                                    <button class="btn-secondary btn"> <i class="fa-solid fa-paperclip"></i> </button>
                                    <input type="text" class="form-control" placeholder="Enter text here...">
                                    <button class="btn btn-primary text-white"><i class="fa fa-send"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>