<html>
<?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<!-- custom css -->
<link rel="stylesheet" href="/StudBud/css/header-profile.css">

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>

    <div class="container-lg mt-1 my-lg-3">
        <div class="row">
            <div class="col-4 col-lg-4 col-xl-3 d-none d-lg-block sticky-top">
                <?php include "/xampp/htdocs/StudBud/components/nav-left.php" ?>
            </div>
            <div class="col-12 col-lg-8 col-xl-9 main">
                <div class="profile-page tx-13">
                    <div class="grid-margin profile-header">
                        <div class="cover">
                            <div class="gray-shade"></div>
                            <figure> <img src="https://bootdey.com/img/Content/bg1.jpg" class="img-fluid" alt=""> </figure>
                            <div class="cover-body d-flex justify-content-between align-items-center">
                                <div class="d-sm-flex flex-row align-items-center d-block gap-2">
                                    <img class="profile-pic" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="profile">
                                    <p class="profile-name m-0">Cojocaru Augustin
                                    </p>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-primary position-relative">
                                        <i class="bi bi-chat"></i>
                                        <span class="d-none d-sm-inline text-truncate">
                                            Trimite un mesaj
                                        </span>
                                        <span class="position-absolute top-0 start-100 translate-middle p-2 bg-success border border-light rounded-circle">
                                            <span class="visually-hidden">New alerts</span>
                                        </span>
                                    </button>
                                    <!-- <i class="bi bi-pencil-square"></i> Edit profile </button>  -->
                                    <div class="btn-group"> <button class="btn btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item d-flex gap-1 align-items-center" href="#">
                                                <i class="bi bi-window-dock text-primary"></i>Visit profile</a>
                                            <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown">
                                                </i>Unfollow</a>
                                            <a class="dropdown-item d-flex gap-1 align-items-center" href="#">
                                                <i class="bi bi-person-x-fill text-primary"></i> Delete from friends</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <nav class="header-links pb-0">
                            <div class="nav nav-tabs navbar-expand" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-timeline-tab" data-bs-toggle="tab" data-bs-target="#nav-timeline" type="button" role="tab" aria-controls="nav-timeline" aria-selected="false">
                                    <div class="d-xl-inline d-none">
                                        <i class="bi bi-book-fill"></i>
                                        <span class="d-md-inline d-none">
                                            Timeline
                                        </span>
                                    </div>
                                    <div class="d-xl-none d-inline">
                                        <i class="bi bi-newspaper"></i>
                                        <span class="d-md-inline d-none">
                                            Postari
                                        </span>
                                    </div>
                                </button>
                                <button class="nav-link d-md-none d-block" id="nav-despre-tab" data-bs-toggle="tab" data-bs-target="#nav-despre" type="button" role="tab" aria-controls="nav-despre" aria-selected="false">
                                    <i class="fa-solid fa-user"></i>
                                    <span class="d-md-inline d-none">
                                        Despre
                                    </span>
                                </button>
                                <button class="nav-link" id="nav-prieteni-tab" data-bs-toggle="tab" data-bs-target="#nav-prieteni" type="button" role="tab" aria-controls="nav-prieteni" aria-selected="true">
                                    <i class="fa-solid fa-user-group"></i>
                                    <span class="d-md-inline d-none">
                                        Prieteni
                                    </span>
                                    <span class="badge rounded-pill bg-info">
                                        212
                                    </span>
                                </button>
                                <button class="nav-link" id="nav-recenzii-tab" data-bs-toggle="tab" data-bs-target="#nav-recenzii" type="button" role="tab" aria-controls="nav-recenzii" aria-selected="false">
                                    <i class="bi bi-star-fill"></i>
                                    <span class="d-md-inline d-none">
                                        Recenzii
                                    </span>
                                    <span class="badge rounded-pill bg-info">
                                        212
                                    </span>
                                </button>
                                <button class="nav-link" id="nav-fisiere-tab" data-bs-toggle="tab" data-bs-target="#nav-fisiere" type="button" role="tab" aria-controls="nav-fisiere" aria-selected="false">
                                    <i class="bi bi-file-earmark-code-fill"></i>
                                    <span class="d-md-inline d-none">
                                        Fisiere
                                    </span>
                                    <span class="badge rounded-pill bg-info">
                                        212
                                    </span>
                                </button>
                            </div>
                        </nav>
                    </div>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-timeline" role="tabpanel" aria-labelledby="nav-timeline-tab">
                            <?php include "/xampp/htdocs/StudBud/components/timeline.php" ?>
                        </div>
                        <div class="tab-pane fade" id="nav-despre" role="tabpanel" aria-labelledby="nav-despre-tab">
                            <?php despre_user(); ?>
                        </div>
                        <div class="tab-pane fade" id="nav-recenzii" role="tabpanel" aria-labelledby="nav-recenzii-tab">
                            <?php include "/xampp/htdocs/StudBud/components/recenzii.php"; ?>
                        </div>
                        <div class="tab-pane fade" id="nav-prieteni" role="tabpanel" aria-labelledby="nav-prieteni-tab">
                            <?php include "/xampp/htdocs/StudBud/components/friends.php"; ?>
                        </div>
                        <div class="tab-pane fade" id="nav-fisiere" role="tabpanel" aria-labelledby="nav-fisiere-tab">
                            <?php include "/xampp/htdocs/StudBud/components/files.php" ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>