<html>

<?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<!-- custom css -->
<link rel="stylesheet" href="/StudBud/css/header-profile.css">

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>
    <div class="container-lg mt-1 my-lg-3">
        <div class="row">
            <div class="col-4 col-lg-4 col-xl-3 d-none d-lg-block sticky-top">
                <?php include "/xampp/htdocs/StudBud/components/nav-left.php" ?>
            </div>
            <div class="col-12 col-lg-8 col-xl-9 main">
                <div class="row">
                    <div class="col-12 col-md-8 right-wrapper">
                        <!-- nav mobile home-search -->
                        <ul class="d-md-none d-flex nav nav-tabs mb-3" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link w-100 text-start active" id="tab-home-feeds-post-tab" data-bs-toggle="pill" data-bs-target="#tab-home-feeds-post" type="button" role="tab" aria-controls="tab-home-feeds-post" aria-selected="true">
                                    <i class="bi bi-house-door"></i> Home
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link w-100 text-start" id="tab-search-posts-tab" data-bs-toggle="pill" data-bs-target="#tab-search-posts" type="button" role="tab" aria-controls="tab-search-posts" aria-selected="false">
                                    <i class="bi bi-search"></i> Cautare
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content" id="v-pills-tabContent">
                            <div class="tab-pane fade show active" id="tab-home-feeds-post" role="tabpanel" aria-labelledby="tab-home-feeds-post-tab">
                                <!-- campul pentru input post -->
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <div class="nav navbar-expand nav-tabs card-header-tabs">
                                            <div class="nav nav-tabs navbar-expand border-0" id="nav-tab" role="tablist"> <button class="nav-link active" id="nav-post-tab" data-bs-toggle="tab" data-bs-target="#nav-post" type="button" role="tab" aria-controls="nav-post" aria-selected="true"> Post </button> <button class="nav-link" id="nav-incarca-tab" data-bs-toggle="tab" data-bs-target="#nav-incarca" type="button" role="tab" aria-controls="nav-incarca" aria-selected="false"> Photos </button> </div>
                                        </div>
                                    </div>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="nav-post" role="tabpanel" aria-labelledby="nav-post-tab">
                                            <div class="card-body"> <textarea name="Post" class="form-control" placeholder="Scrie un post..." id="" rows="3"></textarea> </div>
                                        </div>
                                        <div class="tab-pane fade" id="nav-incarca" role="tabpanel" aria-labelledby="nav-incarca-tab">
                                            <div class="card-body">
                                                <div class="d-flex gap-2"> <input type="file" class="custom-file-input form-control" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01"> <button class="btn  btn-secondary">Upload</button> </div> <small class="text-muted">* Doar fisiere PNG, JPEG, JPG</small>
                                                <div class="mt-3 border-bottom"></div>
                                                <ol class="list-group">
                                                    <div class="row">
                                                        <?php for ($i = 0; $i < 5; $i++) : ?>
                                                            <div class="col-12 col-sm-6 col-lg-12 col-xl-6 mb-2">
                                                                <li class="list-group-item px-0 border-0 border-bottom d-flex justify-content-between align-items-start">
                                                                    <div class="me-auto d-flex flex-row-reverse align-items-center">
                                                                        <div class="ms-2">
                                                                            <div class="fw-bold"><small>sdsddsds.doc</small></div> <small class="form-text text-muted">.doc, 5.3 mb </small>
                                                                        </div> <img class="img-xs rounded" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                                                    </div>
                                                                    <div>
                                                                        <button class="btn btn-sm btn-outline-danger">
                                                                            <small>Sterge</small></button>
                                                                    </div>
                                                                </li>
                                                            </div> <?php endfor; ?>
                                                    </div>
                                                </ol>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <div class="text-info"><i class="bi bi-paperclip"></i> <small>3 files uploaded</small> </div>
                                        <div class="d-flex justify-content-end"> <button class="btn btn-primary">Post</button> </div>
                                    </div>
                                </div>

                                <!-- divider -->
                                <div class="hstack gap-2">
                                    <div class="mb-3 d-flex flex-row-reverse gap-2 align-items-center w-100">
                                        <div class="border-top w-100"></div>

                                        <div class="w-auto d-md-none d-inline">
                                            <!-- Button trigger modal -->
                                            <button class="btn btn-dark hstack gap-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottomv1" aria-controls="offcanvasBottomv1">
                                                <i class="bi bi-funnel-fill"></i> <span class=""><small class="fw-bold">Filtru</small></span>
                                            </button>

                                            <!-- Modal -->
                                            <div class="offcanvas rounded offcanvas-bottom col-12 offset-0 col-sm-10 offset-sm-1 overflow-auto" tabindex="-1" id="offcanvasBottomv1" aria-labelledby="offcanvasBottomv1Label">
                                                <div class="offcanvas-header text-secondary bg-light">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <i class="bi bi-funnel-fill"></i>
                                                        <p class="modal-title"><b>Filtru</b></p>
                                                    </div>
                                                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                </div>
                                                <div class="px-0 offcanvas-body">
                                                    <?php filtru_elemente(); ?>
                                                </div>
                                                <div class="card-footer d-flex justify-content-end">
                                                    <div>
                                                        <button class="btn btn-dark">Filter</button>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <p class="text-muted text-nowrap">Postari cautate</p>
                                    <div class="mb-3 border-top w-100"></div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="tab-search-posts" role="tabpanel" aria-labelledby="tab-search-posts-tab">
                                <div class="card mb-3">
                                    <div class="card-body text-secondary bg-light hstack gap-1">
                                        <label class="m-0 fw-bold">Cautare:</label>
                                        <input type="text" class="form-control" placeholder="Scrie aici cuvantul cheie...">
                                    </div>
                                </div>
                                <!-- divider -->
                                <div class="hstack gap-2">
                                    <div class="mb-3 d-flex flex-row-reverse gap-2 align-items-center w-100">
                                        <div class="border-top w-100"></div>

                                        <div class="w-auto d-md-none d-inline">
                                            <!-- Button trigger modal -->
                                            <button class="btn btn-dark hstack gap-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">
                                                <i class="bi bi-funnel-fill"></i> <span class=""><small class="fw-bold">Filtru</small></span>
                                            </button>

                                            <!-- Modal -->
                                            <div class="offcanvas rounded offcanvas-bottom col-12 offset-0 col-sm-10 offset-sm-1 overflow-auto" tabindex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
                                                <div class="offcanvas-header text-secondary bg-light">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <i class="bi bi-funnel-fill"></i>
                                                        <p class="modal-title"><b>Filtru</b></p>
                                                    </div>
                                                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                </div>
                                                <div class="px-0 offcanvas-body">
                                                    <?php filtru_elemente(); ?>
                                                </div>
                                                <div class="card-footer d-flex justify-content-end">
                                                    <div>
                                                        <button class="btn btn-dark">Filter</button>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <p class="text-muted text-nowrap">Postari cautate</p>
                                    <div class="mb-3 border-top w-100"></div>
                                </div>

                            </div>
                        </div>
                        <!-- postarile -->
                        <?php for ($i = 0; $i < 5; $i++) : ?>
                            <div class="mb-3">
                                <div id="postare-1" class="card postare">
                                    <?php post_without_footer(); ?>

                                    <div class="card-footer">
                                        <div class="justify-content-center">
                                            <div class="d-flex gap-1">
                                                <button class="btn btn-sm btn-light">
                                                    <i class="fa-solid fa-thumbs-up"></i> Like
                                                </button>
                                                <button class="btn btn-sm btn-light"> <i class="fa-solid fa-thumbs-down">
                                                    </i> Dislike
                                                </button>
                                                <button class="btn btn-sm btn-light btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#canvas_comments<?php echo $i; ?>" aria-controls="offcanvasBottom">
                                                    <i class="fa-solid fa-message"></i> Comment</button>
                                            </div>
                                            <div class="col-12 offset-0 col-md-10 offset-md-1 col-lg-6 offset-lg-3 rounded offcanvas offcanvas-bottom" tabindex="-1" id="canvas_comments<?php echo $i; ?>" aria-labelledby="canvas_comments<?php echo $i; ?>Label">
                                                <div class="offcanvas-header text-secondary bg-light">
                                                    <h6 class="offcanvas-title" id="canvas_comments<?php echo $i; ?>Label">Comentarii la postare</h5>
                                                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                                </div>
                                                <div class="offcanvas-body px-0 small">
                                                    <?php
                                                    comentarii_sub_postare(20);
                                                    ?>
                                                </div>
                                                <div class="card-footer">
                                                    <?php comment_input(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>

                    </div>
                    <div class="d-none d-md-block col-12 col-md-4 left-wrapper">
                        <div class="sticky-top">
                            <form class="card mb-3">
                                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                    <b>Filtru</b>
                                    <i class="bi bi-funnel-fill"></i>
                                </div>
                                <?php function filtru_elemente()
                                { ?>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <label for=""><small>Sorteaza dupa:</small></label>
                                            <select class="form-select form-select-sm" id="">
                                                <option selected>Cele mai recente</option>
                                                <option value="">Cele mai vechi</option>
                                            </select>
                                        </li>
                                        <li class="list-group-item">
                                            <label for=""><small>Postari lasate de useri:</small></label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="studenti">
                                                <label class="form-check-label" for="studenti">
                                                    <small>Studenti</small>
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="profesori">
                                                <label class="form-check-label" for="profesori">
                                                    <small>Profesori</small>
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="" id="universitati">
                                                <label class="form-check-label" for="universitati">
                                                    <small>Universitati</small>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                <?php };
                                filtru_elemente(); ?>
                                <div class="card-footer d-flex justify-content-end">
                                    <div>
                                        <button class="btn btn-dark">Filter</button>
                                    </div>
                                </div>
                            </form>
                            <!-- nav desktop home-page -->
                            <li class="list-group-item">
                                <div class="nav flex-column border-0 nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                    <button class="nav-link w-100 text-start active" id="tab-home-feeds-post-tab" data-bs-toggle="pill" data-bs-target="#tab-home-feeds-post" type="button" role="tab" aria-controls="tab-home-feeds-post" aria-selected="true">
                                        <i class="bi bi-house-door"></i> Home</button>
                                    <button class="nav-link w-100 text-start" id="tab-search-posts-tab" data-bs-toggle="pill" data-bs-target="#tab-search-posts" type="button" role="tab" aria-controls="tab-search-posts" aria-selected="false">
                                        <i class="bi bi-search"></i> Cautare</button>
                                </div>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>