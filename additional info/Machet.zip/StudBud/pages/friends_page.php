<?php include "/xampp/htdocs/StudBud/pages/profile.php" ?>

<script>
    $(document).ready(function() {
        $(".profile-page").children(".tab-content").children(".tab-pane").each(function(index, element) {
            $(this).removeClass("show");
            $(this).removeClass("active");
        });
        $("#nav-prieteni").addClass("show");
        $("#nav-prieteni").addClass("active");

        $(".profile-header").children(".header-links").children(".nav-tabs").children(".nav-link").each(function(index, element) {
            $(this).removeClass("active");
        });
        $("#nav-prieteni-tab").addClass("active");

    });
</script>