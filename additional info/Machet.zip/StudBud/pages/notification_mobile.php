<html>
<?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<!-- custom css -->
<link rel="stylesheet" href="/StudBud/css/header-profile.css">

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>
    <div class="container-lg mt-1">
        <div class="card">
            <?php notificari() ?>
            <div class="card-footer text-secondary">
                <small class="text-muted">12 notificari</small>
            </div>
        </div>
    </div>
</body>

</html>