<html>
<html>

<?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<!-- custom css -->
<link rel="stylesheet" href="/StudBud/css/header-profile.css">

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-yes-log.php" ?>
    <div class="container-lg mt-1 my-lg-3">
        <div class="row">
            <div class="col-4 col-lg-4 col-xl-3 d-none d-lg-block">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <button class="nav-link w-100 text-start hstack gap-1 active" id="list-personal-data-tab" data-bs-toggle="tab" data-bs-target="#list-personal-data" type="button" role="tab" aria-controls="list-personal-data" aria-selected="true">
                        <i class="bi bi-file-person"></i>
                        <span class="d-md-block d-none text-truncate">
                            Date personale
                        </span>
                    </button>
                    <button class="nav-link w-100 text-start hstack gap-1" id="list-institution-data-tab" data-bs-toggle="tab" data-bs-target="#list-institution-data" type="button" role="tab" aria-controls="list-institution-data" aria-selected="false">
                        <i class="fa-solid fa-building-columns"></i>
                        <span class="d-none d-md-block">
                            Institutia
                        </span>
                    </button>
                    <button class="nav-link w-100 text-start hstack gap-1" id="list-avatar-tab" data-bs-toggle="tab" data-bs-target="#list-avatar" type="button" role="tab" aria-controls="list-avatar" aria-selected="false">
                        <i class="bi bi-person-bounding-box"></i>
                        <span class="d-md-block d-none">
                            Avatar
                        </span>
                    </button>
                    <button class="nav-link w-100 text-start hstack gap-1" id="list-auth-tab" data-bs-toggle="tab" data-bs-target="#list-auth" type="button" role="tab" aria-controls="list-auth" aria-selected="false">
                        <i class="bi bi-box-arrow-in-right"></i>
                        <span class="d-md-block d-none text-truncate">
                            Date de autentificare
                        </span>
                    </button>
                </div>
            </div>
            <nav class="d-md-none d-inline">
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link hstack gap-1 active" id="list-personal-data-tab" data-bs-toggle="tab" data-bs-target="#list-personal-data" type="button" role="tab" aria-controls="list-personal-data" aria-selected="true">
                        <i class="bi bi-file-person"></i>
                        <span class="d-md-block d-none text-truncate">
                            Date personale
                        </span>
                    </button>
                    <button class="nav-link hstack gap-1" id="list-institution-data-tab" data-bs-toggle="tab" data-bs-target="#list-institution-data" type="button" role="tab" aria-controls="list-institution-data" aria-selected="false">
                        <i class="fa-solid fa-building-columns"></i>
                        <span class="d-none d-md-block">
                            Institutia
                        </span>
                    </button>
                    <button class="nav-link hstack gap-1" id="list-avatar-tab" data-bs-toggle="tab" data-bs-target="#list-avatar" type="button" role="tab" aria-controls="list-avatar" aria-selected="false">
                        <i class="bi bi-person-bounding-box"></i>
                        <span class="d-md-block d-none">
                            Avatar
                        </span>
                    </button>
                    <button class="nav-link hstack gap-1" id="list-auth-tab" data-bs-toggle="tab" data-bs-target="#list-auth" type="button" role="tab" aria-controls="list-auth" aria-selected="false">
                        <i class="bi bi-box-arrow-in-right"></i>
                        <span class="d-md-block d-none text-truncate">
                            Date de autentificare
                        </span>
                    </button>
                </div>
            </nav>

            <form class="col-12 col-lg-8 col-xl-9 main vstack gap-3">
                <div class="">
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="list-personal-data" role="tabpanel" aria-labelledby="personal-data">
                            <div class="form1">
                                <div class="card">
                                    <div class="card-header bg-info text-white">
                                        Date personale
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-floating"> <input minlength="4" maxlength="12" type="text" class="form-control" name="" id="" aria-describedby="emailHelpId" placeholder="Numele" required="required"> <label for="">Numele</label> </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating"> <input minlength="4" maxlength="12" type="text" class="form-control" name="" id="" aria-describedby="emailHelpId" placeholder="Numele" required="required"> <label for="">Prenumele</label> </div>
                                            </div> <small class="form-text text-muted"> * Intre 4 si 12 caractere fiecare</small>
                                        </div>
                                        <div class="separator mb-3"></div>
                                        <div class="form-floating"> <input type="date" class="form-control" name="" id="" placeholder="Anul nasterii" required="required"> <label for="" class="">Anul nasterii</label> </div>
                                        <div class="separator mb-3"></div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-floating"> <select class="form-select" name="" id="" required>
                                                        <!-- <option disabled="disabled" selected="true" value="">Tara</option> -->
                                                        <option>Republica Moldova</option>
                                                        <option>Romania</option>
                                                    </select> <label for="">Tara</label> </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating"> <select class="form-select" name="" id="" required>
                                                        <option>Glodeni</option>
                                                    </select> <label for="">Orasul</label> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex justify-content-end">
                                        <button class="btn btn-success float-right" type="submit">Salveaza</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab-pane fade" id="list-institution-data" role="tabpanel" aria-labelledby="institution-data">
                            <div class="form2">
                                <div class="card">
                                    <div class="card-header bg-info text-white">
                                        Date referitor la institutia de invatamant
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-7 d-flex flex-wrap gap-2">
                                                <input type="radio" class="btn-check" name="options" id="option1" autocomplete="off"><label class="btn btn-outline-primary" for="option1">Student 0*</label>
                                                <input type="radio" class="btn-check" name="options" id="option1" autocomplete="off"> <label class="btn btn-outline-primary" for="option1">Student 1*</label>
                                                <input type="radio" class="btn-check" name="options" id="option2" autocomplete="off"><label class="btn btn-outline-primary" for="option2">Profesor</label>
                                                <input type="radio" class="btn-check" name="options" id="option3" autocomplete="off"> <label class="btn btn-outline-primary" for="option3">Universitate</label>
                                                <ul class="lyst-unstyled text-secondary text-justify">
                                                    <li><small>Student 0* - daca abia esti in cautarea de a depune pentru o universitate</small></li>
                                                    <li><small>Student 1* - daca esti student la o universitate</small></li>
                                                </ul>
                                                <div class="separator mb-3"> </div>
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="form-floating"> <input type="number" class="form-control" placeholder="Introdu numarul" required> <small id="helpId" class="form-text text-muted">* Cel putin 1 institutie</small> <label for="" class="">Nr. de institutii in care ai figurat</label> </div>
                                                <div class="separator mb-3"></div>
                                            </div>
                                        </div>

                                        <div class="accordion" id="accordionFlushExample">
                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="flush-headingOne">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                                        Institutia #1
                                                    </button>
                                                </h2>
                                                <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                                    <div class="accordion-body">
                                                        <div class="form-floating"> <input type="text" class="form-control" placeholder="Denumirea institutiei" required> </input> <label for="" class="">Denumirea institutiei</label> </div>
                                                        <div class="mb-3 separator"></div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-floating"> <select class="form-select" name="" id=""> </select> <label for="">Start</label> </div>
                                                            </div>
                                                            <div class="col">
                                                                <div class="form-floating"> <select class="form-select" name="" id=""> </select> <label for="">Finish</label> </div>
                                                            </div>
                                                        </div>
                                                        <div class="separator mb-3"></div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-floating"> <input type="text" class="form-control" placeholder="ex: Informatica" value="ex: Informatica"> <label for="">Specializarea</label> </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-floating"> <input type="text" class="form-control" placeholder="ex: Lect. univ. dr." value="ex: Lect. univ. dr."> <label for="">Gradul ocupat</label> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex justify-content-end">
                                        <button class="btn btn-success float-right" type="submit">Salveaza</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="list-avatar" role="tabpanel" aria-labelledby="avatar">
                            <div class="form3">
                                <div class="card">
                                    <div class="card-header bg-info text-white">
                                        Avatar
                                    </div>
                                    <div class="card-body">
                                        <label class="custom-file-label" for="inputGroupFile01">Alege avatarul</label>
                                        <div class="d-flex flex-row gap-4 w-100">
                                            <div class="custom-file w-100">
                                                <input type="file" class="custom-file-input form-control" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                                            </div>
                                            <button class="btn btn-danger" disabled> <i class="fa fa-trash" aria-hidden="true"></i> </button>
                                        </div>
                                        <small class="form-text text-muted"> * PNG, JPEG, JPG </small>
                                        <div class="d-flex justify-content-center">
                                            <img src="images/no-avatar.png" alt="" width="150px" class="rounded-circle">
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex justify-content-end">
                                        <button class="btn btn-success float-right" type="submit">Salveaza</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab-pane fade" id="list-auth" role="tabpanel" aria-labelledby="auth">
                            <div class="form4">
                                <div class="card">
                                    <div class="card-header bg-info text-white">
                                        Date de autentificare
                                    </div>
                                    <div class="card-body">
                                        <div class="form-floating"> <input type="email" class="form-control" name="" id="" aria-describedby="emailHelpId" placeholder="Introdu email" required="required"> <label for="">Email</label> </div>
                                        <div class="mb-3 sep"></div>
                                        <div class="row">
                                            <div class="col-md">
                                                <div class="form-floating"> <input type="password" class="form-control" placeholder="Introdu parola dorita" required> <label for="">Parola</label> </div> <small class="form-text text-muted"> * Intre 4 si 12 caractere </small>
                                                <div class="mb-3 sep"></div>
                                            </div>
                                            <div class="col-md">
                                                <div class="form-floating"> <input type="password" class="form-control" placeholder="Confirma parola" required> <label for="">Confirma parola</label> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex justify-content-end">
                                        <button class="btn btn-success float-right" type="submit">Salveaza</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php include "/xampp/htdocs/StudBud/components/footer.php" ?>
</body>

<script>
    $(document).ready(function() {
        $(".footer").removeClass("container");
        $(".footer").addClass("container-lg");
    });
</script>

</html>