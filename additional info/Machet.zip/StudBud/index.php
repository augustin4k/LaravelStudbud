<!DOCTYPE html>
<html lang="en">
<?php include "/xampp/htdocs/StudBud/components/head.php" ?>

<body class="bg-light">
    <?php include "/xampp/htdocs/StudBud/components/header-no-log.php" ?>
    <script src="js/index.js"></script>

    <div class="container my-5">
        <form class="form-signin needs-validation" novalidate>
            <div class="text-center gap-2 mb-3 d-flex align-items-center justify-content-center">
                <i class="fa fa-graduation-cap fa-3x" aria-hidden="true"></i>
                <h1 class="h3 font-weight-normal">Logare</h1>
            </div>
            <div class="form-floating"> <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" required> <label for="floatingInput">Email address</label> </div>
            <div class="form-floating"> <input type="password" class="form-control" id="floatingPassword" placeholder="Password" required> <label for="floatingPassword">Password</label> </div>
            <div class="checkbox mb-3 d-flex justify-content-between"> <label> <input type="checkbox" value="remember-me"> Remember me </label>
                <div> <small><a href="/StudBud/reset-pass.php">Ai uitat parola?</a></small> </div>
            </div> <a href="/StudBud/pages/profile.php" class="w-100 btn btn-lg btn-primary" type="submit"> Sign in</a>
        </form>
    </div>
    <?php include "/xampp/htdocs/StudBud/components/footer.php" ?>
</body>

</html>