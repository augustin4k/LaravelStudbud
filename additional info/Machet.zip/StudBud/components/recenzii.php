<div class="row profile-body">
    <!-- left wrapper start -->
    <div class="col-12 col-md-8 left-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin post">
                <form class="card">
                    <div class="card-header">
                        <b>Lasa o recenzie</b>
                        <i class="bi bi-pencil-fill"></i>
                    </div>
                    <div class="card-body">
                        <textarea name="Post" class="form-control mb-2" placeholder="Scrie aici mesajul..." id="" rows="3"></textarea>
                        <div class="d-flex gap-2">
                            <?php for ($i = 1; $i < 6; $i++) {
                            ?>
                                <div>
                                    <input type="radio" class="btn-check" name="options-outlined" id="<?php echo $i; ?>_stea" autocomplete="off">
                                    <label class="btn <?php if ($i > 3) {
                                                            echo "btn-outline-success";
                                                        } else if (($i < 4) and ($i > 1)) {
                                                            echo "btn-outline-warning";
                                                        } else {
                                                            echo "btn-outline-danger";
                                                        }
                                                        ?>" for="<?php echo $i; ?>_stea">
                                        <small>
                                            <i class="bi bi-star-fill"></i> <?php echo $i; ?>
                                        </small>
                                    </label>
                                </div>
                            <?php
                            } ?>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-end">
                        <div class="d-flex justify-content-end"> <button class="btn btn-primary">Post</button> </div>
                    </div>
                </form>
            </div>

            <div class="d-flex flex-row-reverse gap-2 align-items-center">
                <div class="mb-3 border-top w-100"></div>
                <p class="text-muted">
                    Recenzii
                </p>
                <div class="mb-3 d-flex flex-row-reverse gap-2 align-items-center w-100">
                    <div class="border-top w-100"></div>

                    <div class="w-auto d-md-none d-inline">
                        <!-- Button trigger modal -->
                        <button class="btn btn-dark hstack gap-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">
                            <i class="bi bi-funnel-fill"></i> <span class=""><small class="fw-bold">Filtru</small></span>
                        </button>

                        <!-- Modal -->
                        <div class="offcanvas rounded offcanvas-bottom col-12 offset-0 col-sm-10 offset-sm-1 overflow-auto" tabindex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
                            <div class="offcanvas-header text-secondary bg-light">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-funnel-fill"></i>
                                    <p class="modal-title"><b>Filtru</b></p>
                                </div>
                                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                            <div class="px-0 offcanvas-body">
                                <?php filtru_elemente(); ?>
                            </div>
                            <div class="card-footer d-flex justify-content-end">
                                <div>
                                    <button class="btn btn-dark">Filter</button>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            <?php for ($i = 0; $i < 5; $i++) : ?>
                <div class="col-md-12 grid-margin recenzii">
                    <div id="postare-<?php echo $i; ?>" class="card postare">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center flex-row-reverse gap-3">
                                <div class="d-flex align-items-center"> <img class="img-xs rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                    <div class="d-flex flex-column"> <b>Cojocaru Augustin</b> <small class="text-muted">1 min ago</small> </div>
                                </div>
                                <div>
                                    <button class="btn btn-success" disabled>
                                        <small>
                                            <i class="bi bi-star-fill"></i> 5
                                        </small>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <div class="btn-group"> <button class="btn btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                                    <div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown"></i>Unfollow</a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-clipboard text-primary"></i>Copy link</a> </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div> <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt=""> </div>
                            <div class="vr"></div>
                            <div> <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt=""> </div>
                            <div class="vr"></div>
                            <div> <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt=""> </div>
                        </div>
                        <div class="card-body"> <small class="card-text text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde quasi blanditiis eligendi dolore maiores dolores, cupiditate alias voluptatibus numquam possimus in delectus optio nobis sint non nesciunt! Quae, at nobis?</small>
                            <div class="my-3"></div>
                            <div class="d-flex align-items-center gap-2"> <small class="text-muted">111 likes</small>
                                <div class="vr"></div> <small class="text-muted">111 dislikes</small>
                                <div class="vr"></div> <small class="text-muted">111 comments</small>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="justify-content-center">
                                <div class="d-flex gap-1">
                                    <button class="btn btn-sm btn-light">
                                        <i class="fa-solid fa-thumbs-up"></i> Like
                                    </button>
                                    <button class="btn btn-sm btn-light"> <i class="fa-solid fa-thumbs-down">
                                        </i> Dislike
                                    </button>
                                    <button class="btn btn-sm btn-light btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#canvas_recenzii<?php echo $i; ?>" aria-controls="offcanvasBottom">
                                        <i class="fa-solid fa-message"></i> Comment</button>
                                </div>
                                <div class="col-12 offset-0 col-md-10 offset-md-1 col-lg-6 offset-lg-3 rounded offcanvas offcanvas-bottom" tabindex="-1" id="canvas_recenzii<?php echo $i; ?>" aria-labelledby="canvas_recenzii<?php echo $i; ?>Label">
                                    <div class="offcanvas-header text-secondary bg-light">
                                        <h6 class="offcanvas-title" id="canvas_recenzii<?php echo $i; ?>Label">Comentarii la postare</h5>
                                            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                    </div>
                                    <div class="offcanvas-body px-0 small">
                                        <?php
                                        comentarii_sub_postare(20);
                                        ?>
                                    </div>
                                    <div class="card-footer">
                                        <?php comment_input(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
    <div class="d-none d-md-block col-12 col-md-4 right-wrapper">
        <div class="row sticky-top">
            <div class="col-md-12 grid-margin">
                <form class="card">
                    <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                        <b>Filtru</b>
                        <i class="bi bi-funnel-fill"></i>
                    </div>
                    <?php function filtru_elemente()
                    { ?>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <label for=""><small>Sorteaza dupa:</small></label>
                                <select class="form-select form-select-sm" id="">
                                    <option selected>Data - Asc</option>
                                    <option value="">Data - Desc</option>
                                    <option value="">Nr. like-uri - Asc</option>
                                    <option value="">Nr. like-uri - Desc</option>
                                    <option value="">Nr. comentarii - Asc</option>
                                    <option value="">Nr. comentarii - Desc</option>
                                </select>
                            </li>
                            <li class="list-group-item">
                                <label for=""><small>Recenzii lasate de useri:</small></label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="studenti">
                                    <label class="form-check-label" for="studenti">
                                        <small>Studenti</small>
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="profesori">
                                    <label class="form-check-label" for="profesori">
                                        <small>Profesori</small>
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="universitati">
                                    <label class="form-check-label" for="universitati">
                                        <small>Universitati</small>
                                    </label>
                                </div>
                            </li>
                            <li class="list-group-item">
                                <label for=""><small>Recenzii de:</small></label>
                                <?php for ($i = 1; $i < 6; $i++) : ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="<?php echo $i; ?>-stele">
                                        <label class="form-check-label" for="<?php echo $i; ?>-stele">
                                            <small><?php echo $i; ?> <i class="bi bi-star-fill"></i>
                                            </small>
                                        </label>
                                    </div>
                                <?php endfor; ?>
                            </li>
                        </ul>
                    <?php };
                    filtru_elemente(); ?>
                    <div class="card-footer d-flex justify-content-end">
                        <div>
                            <button class="btn btn-dark">Filter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>