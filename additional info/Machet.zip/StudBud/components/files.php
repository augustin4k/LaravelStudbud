<div class="row profile-body">
    <!-- left wrapper start -->
    <div class="col-12 col-md-8 left-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin post">
                <form class="card">
                    <div class="card-header">
                        <b>Incarca aici fisierele</b>
                        <i class="bi bi-file-earmark-plus-fill"></i>
                    </div>
                    <div class="card-body">
                        <div class="d-flex gap-2"> <input type="file" class="custom-file-input form-control" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01"> <button class="btn  btn-secondary">Upload</button> </div>
                        <!-- <small class="text-muted">* Doar fisiere PNG, JPEG, JPG</small> -->
                        <div class="mt-3">
                            <div class="border-bottom"></div>
                        </div>
                        <ol class="list-group border-0">
                            <!-- <div class="mx-3"> -->
                            <div class="row">
                                <?php for ($i = 0; $i < 5; $i++) : ?>
                                    <div class="col-12 col-sm-6 col-lg-12 col-xl-6 mb-2">
                                        <li class="list-group-item px-0 border-0 border-bottom d-flex justify-content-between align-items-start">
                                            <div class="me-auto d-flex flex-row-reverse align-items-center">
                                                <div class="ms-2">
                                                    <div class="fw-bold"><small>sdsddsds.doc</small></div>
                                                    <small class="form-text text-muted">.doc, 5.3 mb
                                                    </small>
                                                </div>
                                                <div class="p-2 align-self-center text-success bg-success bg-opacity-10 rounded-circle h-100">.doc</div>
                                            </div>
                                            <div><button class="btn btn-sm btn-outline-danger"><small>Sterge</small></button></div>
                                        </li>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <!-- </div> -->
                        </ol>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <div class="text-info"><i class="bi bi-paperclip"></i> <small>3 files uploaded</small> </div>
                        <div class="d-flex justify-content-end"> <button class="btn btn-primary">Incarca</button> </div>
                    </div>
                </form>
            </div>

            <div class="d-flex flex-row-reverse gap-2 align-items-center">
                <div class="mb-3 border-top w-100"></div>
                <p class="text-muted">
                    Documente
                </p>
                <div class="mb-3 d-flex flex-row-reverse gap-2 align-items-center w-100">
                    <div class="border-top w-100"></div>

                    <div class="w-auto d-md-none d-inline">
                        <!-- Button trigger modal -->
                        <button class="btn btn-info text-white hstack gap-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasCompartimente" aria-controls="offcanvasCompartimente">
                            <i class="bi bi-bookshelf"></i>
                            <small class="fw-bold">Compartimente</small></span>
                        </button>

                        <!-- Modal -->
                        <div class="offcanvas offcanvas-bottom col-12 col-sm-10 offset-sm-1 rounded" tabindex="-1" id="offcanvasCompartimente" aria-labelledby="offcanvasCompartimenteLabel">
                            <div class="offcanvas-header text-secondary rounded-top bg-light">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-bookshelf"></i>
                                    <small class="fw-bold">Compartimente</small></span>
                                </div>
                                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                            <div class="offcanvas-body px-0">
                                <?php compartimente(); ?>
                            </div>
                            <form class="card-footer">
                                <label for=""><small>Doresti sa adaugi compartiment nou?</small></label>
                                <div class="d-flex gap-2">
                                    <input type="text" class="form-control" placeholder="Denumirea...">
                                    <button class="btn btn-primary "><i class="bi bi-plus-circle-fill"></i></button>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-12 grid-margin documente">
                <div class="row">
                    <?php for ($i = 0; $i < 10; $i++) :
                    ?>
                        <div class="col-6 col-sm-4 col-md-6 col-xl-4 grid-margin">
                            <div class="card">
                                <div class="d-flex justify-content-center card-body my-auto position-relative">
                                    <div class="position-absolute top-0 end-0 p-2">
                                        <button class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </div>
                                    <i class="bi bi-filetype-docx fa-4x text-primary d-sm-inline d-none"></i>
                                    <i class="bi bi-filetype-docx fa-3x text-primary d-sm-none d-inline"></i>
                                </div>
                                <div class="card-footer">
                                    <h6 class="card-title text-primary"><a href="">Lorem, ipsum dolor.doc</a></h6>
                                    <small class="card-text form-text text-muted">
                                        Adaugat: Jan 11, 2014
                                    </small>
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <?php for ($i = 0; $i < 5; $i++) : ?>
            <?php endfor; ?>
        </div>
    </div>
    <div class="d-none d-md-block col-12 col-md-4 right-wrapper">
        <div class="row sticky-top">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-header bg-info text-white d-flex align-items-center justify-content-between">
                        <p class="m-0"><b>Compartimente</b></p>
                        <i class="bi bi-bookshelf"></i>
                    </div>
                    <?php function compartimente()
                    { ?>
                        <div class="card-body">
                            <div class="nav nav-pills flex-column align-items-start" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <button class="nav-link w-100 text-start active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Home</button>
                                <button class="nav-link w-100 text-start" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Profile</button>
                                <button class="nav-link w-100 text-start" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Messages</button>
                                <button class="nav-link w-100 text-start" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">Settings</button>
                            </div>
                            <!-- <div class="tab-content" id="v-pills-tabContent">
                                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">...</div>
                                    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">...</div>
                                    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">...</div>
                                    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">...</div>
                                </div> -->
                        </div>
                    <?php };
                    compartimente(); ?>
                    <form class="card-footer">
                        <label for="" class="small"><small>Doresti sa adaugi compartiment nou?</small></label>
                        <div class="d-flex gap-2">
                            <input type="text" class="form-control" placeholder="Denumirea...">
                            <button class="btn btn-primary "><i class="bi bi-plus-circle-fill"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>