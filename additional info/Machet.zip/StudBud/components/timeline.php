<div class="row profile-body">
    <!-- left wrapper start -->
    <div class="d-none d-md-block col-12 col-md-4 left-wrapper">
        <div class="row sticky-top">
            <?php function despre_user()
            { ?>
                <div class="col-md-12 grid-margin">
                    <div class="card">
                        <div class="card-header d-flex align-items-center justify-content-between bg-info text-white">
                            <p class="m-0 card-title fw-bold"> Despre </p>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item text-center bg-light"> <small> <i class="bi bi-file-person"></i> <span class="card-text text-truncate"> Date personale </span> </small> </li>
                            <li class="text-secondary list-group-item d-flex align-items-center gap-1"> <small> <b>Tip user:</b> Student </small> </li>
                            <li class="text-secondary list-group-item"> <small> <b>Nume:</b> Cojocaru </small> </li>
                            <li class="text-secondary list-group-item"> <small> <b>Prenume:</b> Augustin </small> </li>
                            <li class="text-secondary list-group-item d-flex align-items-center gap-1"> <span class="text-truncate"> <small> <b>Anul nasterii:</b> 11.09.2000</span> </small> </li>
                            <li class="list-group-item text-center bg-light"> <small> <i class="fa-solid fa-building-columns"></i> <span class="card-text text-truncate"> Studii </span> </small> </li>
                            <li class="text-secondary list-group-item"> <small>
                                    <div class="d-flex align-items-center gap-1"> <b> 1. </b> <span class="text-truncate" data-bs-toggle="tooltip" data-bs-placement="top" title="1 Decembrie 1918 (Licenta)"> 1 Decembrie 1918 (Licensdasdata) </span> </div> <small class="text-muted text-truncate float-right">Informatica (1999-2000)</small>
                                </small> </li>
                            <li class="text-secondary list-group-item"> <small>
                                    <div class="d-flex align-items-center gap-1"> <b> 2. </b> <span class="text-truncate" data-bs-toggle="tooltip" data-bs-placement="top" title="1 Decembrie 1918 (Licenta)"> 1 Decembrie 1918 (Licenta) </span> </div> <small class="text-muted text-truncate float-right">Economie (1999-2000)</small>
                                </small> </li>
                        </ul>
                    </div>
                </div>
            <?php }
            despre_user(); ?>
            <div class="col-md-12 grid-margin">
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button collapsed bg-info text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <p class="m-0"><b>Prieteni comuni</b>
                                    <span class="badge rounded-pill bg-secondary">33</span>
                                </p>
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div class="list-group list-group list-group-flush">
                                <div class="list-group-item d-flex justify-content-between align-items-center ">
                                    <div class="d-flex align-items-center"> <img class="img-xs rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                        <div class="d-flex flex-column"> <b>Cojocaru Augustin</b><small class="text-muted">12 prieteni comuni</small> </div>
                                    </div>
                                    <div>
                                        <div class="btn-group"> <button class="btn btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                                            <div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-window-dock text-primary"></i>Visit profile </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-chat text-primary"></i>Scrie un mesaj </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown"> </i>Unfollow</a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-person-x-fill text-primary"></i> Delete from friends</a> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="list-group-item d-flex justify-content-between align-items-center ">
                                    <div class="d-flex align-items-center"> <img class="img-xs rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                        <div class="d-flex flex-column"> <b>Cojocaru Augustin</b><small class="text-muted">12 prieteni comuni</small> </div>
                                    </div>
                                    <div>
                                        <div class="btn-group"> <button class="btn btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                                            <div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-window-dock text-primary"></i>Visit profile </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-chat text-primary"></i>Scrie un mesaj </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown"> </i>Unfollow</a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-person-x-fill text-primary"></i> Delete from friends</a> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-8 right-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-header">
                        <div class="nav navbar-expand nav-tabs card-header-tabs">
                            <div class="nav nav-tabs navbar-expand border-0" id="nav-tab" role="tablist"> <button class="nav-link active" id="nav-post-tab" data-bs-toggle="tab" data-bs-target="#nav-post" type="button" role="tab" aria-controls="nav-post" aria-selected="true"> Post </button> <button class="nav-link" id="nav-incarca-tab" data-bs-toggle="tab" data-bs-target="#nav-incarca" type="button" role="tab" aria-controls="nav-incarca" aria-selected="false"> Photos </button> </div>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="nav-post" role="tabpanel" aria-labelledby="nav-post-tab">
                            <div class="card-body"> <textarea name="Post" class="form-control" placeholder="Scrie un post..." id="" rows="3"></textarea> </div>
                        </div>
                        <div class="tab-pane fade" id="nav-incarca" role="tabpanel" aria-labelledby="nav-incarca-tab">
                            <div class="card-body">
                                <div class="d-flex gap-2"> <input type="file" class="custom-file-input form-control" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01"> <button class="btn  btn-secondary">Upload</button> </div> <small class="text-muted">* Doar fisiere PNG, JPEG, JPG</small>
                                <div class="mt-3 border-bottom"></div>
                                <ol class="list-group">
                                    <div class="row">
                                        <?php for ($i = 0; $i < 5; $i++) : ?>
                                            <div class="col-12 col-sm-6 col-lg-12 col-xl-6 mb-2">
                                                <li class="list-group-item px-0 border-0 border-bottom d-flex justify-content-between align-items-start">
                                                    <div class="me-auto d-flex flex-row-reverse align-items-center">
                                                        <div class="ms-2">
                                                            <div class="fw-bold"><small>sdsddsds.doc</small></div> <small class="form-text text-muted">.doc, 5.3 mb </small>
                                                        </div> <img class="img-xs rounded" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                                    </div>
                                                    <div>
                                                        <button class="btn btn-sm btn-outline-danger">
                                                            <small>Sterge</small></button>
                                                    </div>
                                                </li>
                                            </div> <?php endfor; ?>
                                    </div>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <div class="text-info"><i class="bi bi-paperclip"></i> <small>3 files uploaded</small> </div>
                        <div class="d-flex justify-content-end"> <button class="btn btn-primary">Post</button> </div>
                    </div>
                </div>
            </div>
            <div class="d-flex gap-2 align-items-center">
                <div class="mb-3 border-top w-100"></div>
                <p class="text-muted"> Postari </p>
                <div class="mb-3 border-top w-100"></div>
            </div>
            <?php for ($i = 0; $i < 5; $i++) : ?>
                <div class="col-md-12 grid-margin">
                    <div id="postare-1" class="card postare">
                        <?php post_without_footer(); ?>

                        <div class="card-footer">
                            <div class="justify-content-center">
                                <div class="d-flex gap-1">
                                    <button class="btn btn-sm btn-light">
                                        <i class="fa-solid fa-thumbs-up"></i> Like
                                    </button>
                                    <button class="btn btn-sm btn-light"> <i class="fa-solid fa-thumbs-down">
                                        </i> Dislike
                                    </button>
                                    <button class="btn btn-sm btn-light btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#canvas_comments<?php echo $i; ?>" aria-controls="offcanvasBottom">
                                        <i class="fa-solid fa-message"></i> Comment</button>
                                </div>
                                <div class="col-12 offset-0 col-md-10 offset-md-1 col-lg-6 offset-lg-3 rounded offcanvas offcanvas-bottom" tabindex="-1" id="canvas_comments<?php echo $i; ?>" aria-labelledby="canvas_comments<?php echo $i; ?>Label">
                                    <div class="offcanvas-header text-secondary bg-light">
                                        <h6 class="offcanvas-title" id="canvas_comments<?php echo $i; ?>Label">Comentarii la postare</h5>
                                            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                    </div>
                                    <div class="offcanvas-body px-0 small">
                                        <?php
                                        comentarii_sub_postare(20);
                                        ?>
                                    </div>
                                    <div class="card-footer">
                                        <?php comment_input(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div>