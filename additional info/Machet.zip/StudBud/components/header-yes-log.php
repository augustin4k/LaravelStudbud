<link rel="stylesheet" href="/StudBud/css/drop_menu_user.css">

<nav class="navbar navbar-light bg-white navbar-yes-log">
    <div class="container-lg ">
        <div class="w-100">
            <div class="d-xl-flex row align-items-center d-none">
                <div class="col-4 col-lg-4 col-xl-3">
                    <?php function logo_bar()
                    { ?>
                        <a class="navbar-brand" href="/StudBud/index.php"> <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                            <span class="d-none d-md-inline">
                                StudBud
                            </span>
                            <span class="d-inline d-md-none">
                                SB
                            </span>
                        </a>
                    <?php };
                    logo_bar(); ?>
                </div>
                <div class="col-12 col-lg-8 col-xl-9 main">
                    <div class="row">
                        <div class="col-12 col-md-8 search-navbar">

                            <?php function search_bar($tip_navbar)
                            { ?>
                                <div class="d-flex gap-2">
                                    <input type="text" placeholder="Search..." class="form-control">
                                    <button class="btn btn-secondary"><i class="bi bi-search"></i></button>
                                    <div class="d-lg-block d-none">
                                        <button class="btn h-100 btn-dark position-relative" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNotification<?php echo $tip_navbar; ?>" aria-controls="offcanvasNotification<?php echo $tip_navbar; ?>">
                                            <i class="bi bi-bell-fill"></i>
                                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                                99+
                                                <span class="visually-hidden">unread messages</span>
                                            </span>
                                        </button>

                                        <div class="offcanvas offcanvas-top rounded h-75 col-6 offset-3" tabindex="-1" id="offcanvasNotification<?php echo $tip_navbar; ?>" aria-labelledby="offcanvasNotification<?php echo $tip_navbar; ?>Label">
                                            <div class="offcanvas-header text-white bg-primary">
                                                <div class="d-flex align-items-center gap-2">
                                                    <i class="bi bi-bell-fill"></i>
                                                    <small class="fw-bold">Notificari</small></span>
                                                </div>
                                                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                            </div>
                                            <div class="offcanvas-body px-0 small">
                                                <?php notificari() ?>
                                            </div>
                                            <div class="card-footer bg-light text-secondary">
                                                <small class="text-muted">12 notificari</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php };
                            search_bar("mare"); ?>
                        </div>
                        <div class="col-12 col-md-4 d-flex justify-content-end">
                            <?php function menu_user()
                            { ?>
                                <div class="btn-group dropstart">
                                    <button type="button" class="btn btn-light dropdown-toggle py-0" data-bs-toggle="dropdown" aria-expanded="false">
                                        <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="" width="37.6px" class="rounded-circle avatar">
                                    </button>
                                    <div class="dropdown-menu p-0">
                                        <div class="list-group list-group-flush rounded">
                                            <a href="#" class="list-group-item list-group-item-action d-flex align-items-center gap-2" aria-current="true">
                                                <i class="bi bi-person-circle"></i>
                                                <small>Profilul meu</small>
                                            </a>
                                            <a href="/StudBud/pages/settings.php" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
                                                <i class="bi bi-gear-fill"></i>
                                                <small>Settings</small>
                                            </a>
                                            <!-- <div class="dropdown-divider"></div> -->
                                            <a href="#" class="list-group-item list-group-item-action d-flex align-items-center gap-2 text-danger">
                                                <i class="bi bi-box-arrow-right"></i>
                                                <small>Logout</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php };
                            menu_user(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- pentru mediu -->
            <div class="d-lg-flex d-xl-none d-none row">
                <div class="col-12 col-md-8 search-navbar">
                    <div class="d-flex justify-content-between gap-2">
                        <div><?php logo_bar(); ?></div>
                        <div class="w-100"><?php search_bar("mediu"); ?></div>
                    </div>
                </div>
                <div class="col-12 col-md-4 d-flex justify-content-end">
                    <div><?php menu_user(); ?></div>
                </div>
            </div>
            <!-- pentru ecran mic -->
            <div class="hstack d-lg-none d-sm-flex justify-content-between gap-2">
                <div><?php logo_bar(); ?></div>
                <div class=""><?php search_bar("mic"); ?></div>
                <div><?php menu_user(); ?></div>
            </div>
        </div>
    </div>
</nav>

<!-- bara suplimentara pentru mobile -->
<div class="d-lg-none d-block navbar-mobile pt-2 container-lg bg-light border-top border-bottom shadow-sm">
    <div class="nav nav-tabs nav-justified">
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/feed.php'" href="/StudBud/pages/feed.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-1x bi bi-newspaper"></i>
            </button>
        </div>
        <!-- <div class="vr bg-secondary"></div> -->
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/chat.php'" href="/StudBud/pages/chat.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-1x fa fa-comments-o" aria-hidden="true"></i>
            </button>
        </div>
        <!-- <div class="vr bg-secondary"></div> -->
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/friends_page.php'" href="/StudBud/pages/friends_page.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-solid fa-user-group fa-1x"></i>
            </button>
        </div>
        <!-- <div class="vr bg-secondary"></div> -->
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/notification_mobile.php'" href="/StudBud/pages/notification_mobile.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-1x bi bi-bell-fill"></i>
            </button>
        </div>
        <!-- <div class="vr bg-secondary"></div> -->
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/advanced_search.php'" href="/StudBud/pages/advanced_search.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-1x bi bi-search"></i>
            </button>
        </div>
        <div class="nav-item">
            <button type="button" onclick="location.href='/StudBud/pages/profile.php'" href="/StudBud/pages/profile.php" class="py-3 d-flex align-items-center justify-content-center btn nav-link">
                <i class="fa-1x bi bi-person-circle"></i>
            </button>
        </div>

    </div>
</div>