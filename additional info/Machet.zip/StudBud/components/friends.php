<div class="row">
    <div class="col-12 col-md-8 left-wrapper">
        <div class="mb-3 card d-md-none d-block">
            <div class="card-header border-bottom-0 text-white bg-info fw-bold">Sugestii de prietenii</div>
            <div class="card-body overflow-auto">
                <ul class="list-group list-group-horizontal scroll_horizontal gap-2 border-0">
                    <?php for ($i = 0; $i < 10; $i++) : ?>
                        <li class="list-group-item border">
                            <?php
                            prieten_item_list();
                            ?>
                        </li>
                    <?php endfor; ?>
                </ul>
            </div>
        </div>
        <div class="grid-margin cerere-prietenie">
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <p class="m-0"><b>Cereri de prietenii</b>
                                <span class="badge rounded-pill bg-secondary">33</span>
                            </p>
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <ul class="list-group list-group-flush">
                            <?php for ($i = 0; $i < 2; $i++) : ?>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-start">
                                        <img width="40px" class="rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                        <div class="d-flex flex-column w-100">
                                            <div class="">
                                                <div class="d-flex justify-content-between gap-2">
                                                    <small class="card-text fw-bold">
                                                        Cojocaru Augustin
                                                        <span class="badge rounded-pill bg-success">Online</span>
                                                    </small>
                                                    <div class="d-flex flex-row gap-2"> <button class="btn  btn-outline-primary"> <i class="bi bi-person-plus-fill"></i> </button> <button class="btn  btn-outline-danger"> <i class="bi bi-person-x-fill"></i> </button> </div>
                                                </div>
                                            </div>
                                            <small class="text-muted">13 prieteni comuni</small>
                                        </div>
                                    </div>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                </div>

            </div>

        </div>
        <div class="grid-margin">
            <div class="card">
                <div class="card-header">
                    <div class="nav navbar-expand nav-tabs card-header-tabs">
                        <div class="nav nav-tabs navbar-expand border-0" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="nav-prieteni-totali-tab" data-bs-toggle="tab" data-bs-target="#nav-prieteni-totali" type="button" role="tab" aria-controls="nav-prieteni-totali" aria-selected="true">
                                <small>Toti prietenii</small>
                                <span class="badge rounded-pill bg-secondary">999</span>
                            </button>
                            <button class="nav-link" id="nav-prieteni-online-tab" data-bs-toggle="tab" data-bs-target="#nav-prieteni-online" type="button" role="tab" aria-controls="nav-prieteni-online" aria-selected="false">
                                <small>Prieteni online</small>
                                <span class="badge rounded-pill bg-secondary">0</span>
                            </button>
                            <button class="nav-link" id="nav-prieteni-comuni-tab" data-bs-toggle="tab" data-bs-target="#nav-prieteni-comuni" type="button" role="tab" aria-controls="nav-prieteni-comuni" aria-selected="false">
                                <small>Prieteni comuni</small>
                                <span class="badge rounded-pill bg-secondary">0</span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="nav-prieteni-totali" role="tabpanel" aria-labelledby="nav-prieteni-totali-tab">
                        <div class="card-body border-bottom">
                            <input type="text" placeholder="Search..." class="form-control form-control-sm">
                        </div>
                        <ul class="list-group list-group-flush" id="">
                            <?php for ($i = 1; $i <= 2; $i++) : ?>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-start">
                                        <img width="40px" class="rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                                        <div class="d-flex flex-column w-100">
                                            <div class="">
                                                <div class="d-flex justify-content-between ">
                                                    <small class="card-text fw-bold">
                                                        Cojocaru Augustin
                                                        <span class="badge rounded-pill bg-success">Online</span>
                                                    </small>
                                                    <div class="btn-group"> <button class="btn  btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                                                        <div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-window-dock text-primary"></i>Visit profile </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-chat text-primary"></i>Scrie un mesaj </a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown"> </i>Unfollow</a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-person-x-fill text-primary"></i> Delete from friends</a> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <small class="text-muted">13 prieteni comuni</small>
                                        </div>
                                    </div>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                    <div class="tab-pane fade" id="nav-prieteni-online" role="tabpanel" aria-labelledby="nav-prieteni-online-tab">
                        <div class="card-body border-bottom">
                            <input type="text" placeholder="Search..." class="form-control form-control-sm">
                        </div>
                        <div class="card-body text-center">
                            Nu ai niciun prieten online...
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-prieteni-comuni" role="tabpanel" aria-labelledby="nav-prieteni-comuni-tab">
                        <div class="card-body border-bottom">
                            <input type="text" placeholder="Search..." class="form-control form-control-sm">
                        </div>
                        <div class="card-body text-center">
                            Nu ai niciun prieten online...
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="d-none d-md-block col-12 col-md-4 right-wrapper">
        <div class="grid-margin card">
            <div class="card-header bg-info text-white">
                <b>Sugestii de prieteni</b>
            </div>
            <ul class="list-group list-group-flush border-0">
                <?php for ($i = 0; $i < 3; $i++) : ?>
                    <li class="list-group-item">
                        <?php
                        prieten_item_list();
                        ?>
                    </li>
                <?php endfor; ?>
            </ul>

        </div>
    </div>
</div>