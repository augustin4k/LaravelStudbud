<!-- pentru elementul de lista prieten -->
<?php function prieten_item_list()
{ ?>
    <div class="d-flex align-items-start">
        <img width="40px" class="rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
        <div class="d-flex flex-column w-100">
            <div class="">
                <div class="d-flex justify-content-between gap-2">
                    <small class="card-text fw-bold d-md-inline d-flex flex-column align-items-start">
                        Cojocaru Augustin
                        <span class="badge rounded-pill bg-success">Online</span>
                    </small>
                    <div>
                        <button class="btn btn-outline-primary"><i class="bi bi-person-plus-fill"></i> </button>
                    </div>
                </div>
            </div>
            <small class="text-muted">13 prieteni comuni</small>
        </div>
    </div>
<?php };

function comentariu($sub_comment = 1, $id_comment)
{ ?>
    <div class="list-group-item <?php if ($sub_comment == 1) echo "bg-light"; ?> d-flex gap-3 py-3">
        <div class="rounded-circle">
            <a class="d-flex">
                <?php if ($sub_comment == 1) : ?>
                    <div class="d-flex" style="width: 15px;">
                    </div>
                    <img width="25" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                <?php else : ?>
                    <img width="40" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                <?php endif; ?>
            </a>
        </div>
        <div class="vstack gap-2">
            <div class="vstack gap-2 justify-content-between">
                <h6 class="mb-0">Cojocaru Augustin</h6>

                <p class="mb-0 opacity-75">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum adipisci veritatis consequuntur accusantium, aperiam totam. Quidem suscipit vero veniam quae nulla assumenda iusto, quo officiis eligendi! Nulla itaque reprehenderit voluptatum quibusdam exercitationem, dolor laudantium est odit atque illo illum molestiae quae. Possimus nesciunt rem at placeat repudiandae excepturi quia facere?
                </p>
            </div>
            <div class="hstack justify-content-between gap-2">
                <div class="hstack gap-2">
                    <button class="btn btn-secondary btn-sm">Reply</button>
                    <button class="btn btn-secondary btn-sm">Likes (13)</button>
                </div>
                <small class="opacity-50 text-nowrap">24 Jan 2013</small>
            </div>
        </div>
    </div>
<?php }; ?>

<?php function comentarii_sub_postare($nr_comentarii)
{ ?>
    <div class="list-group list-group-flush vstack align-items-center">
        <?php for ($id_coment = 0; $id_coment < $nr_comentarii; $id_coment++) {
        ?>
            <?php comentariu(0, $id_coment); ?>
        <?php comentariu(1, $id_coment);
        } ?>
    </div>
<?php }; ?>

<?php function comment_input()
{ ?>
    <form class="hstack gap-1">
        <a href="" class="rounded-circle">
            <img width="50px" class=" rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
        </a>
        <textarea class="form-control" name="" id="" rows="1" placeholder="Lasa aici un comentariu..."></textarea>
        <button class="btn btn-primary"><i class="bi bi-send-fill"></i></button>
    </form>

<?php }; ?>

<?php function post_without_footer()
{ ?>
    <div class="card-header d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center"> <img class="img-xs rounded-circle me-1" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
            <div class="d-flex flex-column"> <b>Cojocaru Augustin</b> <small class="text-muted">1 min ago</small> </div>
        </div>
        <div>
            <div class="btn-group"> <button class="btn btn-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa-solid fa-ellipsis"></i> </button>
                <div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"><i class="text-primary bi bi-emoji-frown"></i>Unfollow</a> <a class="dropdown-item d-flex gap-1 align-items-center" href="#"> <i class="bi bi-clipboard text-primary"></i>Copy link</a> </div>
            </div>
        </div>
    </div>
    <div class="overflow-auto h-100">
        <div class="hstack">
            <div> <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt=""> </div>
            <div class="vr"></div>
            <div>
                <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
            </div>
            <div class="vr"></div>
            <div> <img class="img-fluid" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt=""> </div>
        </div>
        <div class="card-body">
            <small class="card-text text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde quasi blanditiis eligendi dolore maiores dolores, cupiditate alias voluptatibus numquam possimus in delectus optio nobis sint non nesciunt! Quae, at nobis?</small>
            <div class="my-3"></div>
            <div class="d-flex align-items-center gap-2"> <small class="text-muted">111 likes</small>
                <div class="vr"></div> <small class="text-muted">111 dislikes</small>
                <div class="vr"></div> <small class="text-muted">111 comments</small>
            </div>
        </div>
    </div>
<?php }; ?>

<?php function notificari()
{ ?>
    <div class="list-group small list-group-flush">
        <?php for ($i = 0; $i < 3; $i++) { ?>
            <!-- pentru like-uri -->
            <a href="#" class="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                <div class="rounded-circle">
                    <div class="position-relative">
                        <img width="40" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                        <span class="position-absolute notification-badge translate-middle badge rounded-pill bg-danger">
                            <i class="bi bi-heart-fill"></i><span class="visually-hidden">unread messages</span>
                        </span>
                    </div>
                </div>
                <div class="d-flex gap-2 w-100 justify-content-between">
                    <div>
                        <h6 class="mb-0">Cojocaru Augustin ti-a lasat un like la postarea:</h6>

                        <div class="d-flex gap-2">

                            <p class="mb-0 opacity-75 text-custom-truncate">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum adipisci veritatis consequuntur accusantium, aperiam totam. Quidem suscipit vero veniam quae nulla assumenda iusto, quo officiis eligendi! Nulla itaque reprehenderit voluptatum quibusdam exercitationem, dolor laudantium est odit atque illo illum molestiae quae. Possimus nesciunt rem at placeat repudiandae excepturi quia facere?
                            </p>
                            <img width="40" height="40" class="" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                        </div>
                    </div>
                    <small class="opacity-50 text-nowrap">24 Jan 2013</small>
                </div>
            </a>
        <?php }; ?>
        <!-- pentru coment-uri -->
        <a href="#" class="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
            <div class="rounded-circle">
                <div class="position-relative">
                    <img width="40" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                    <span class="position-absolute notification-badge translate-middle badge rounded-pill bg-success">
                        <i class="fa-solid fa-message"></i><span class="visually-hidden">unread messages</span>
                    </span>
                </div>
            </div>
            <div class="d-flex gap-2 w-100 justify-content-between">
                <div>
                    <h6 class="mb-0">Cojocaru Augustin ti-a lasat un comentariu la postarea:</h6>

                    <div class="d-flex gap-2">

                        <p class="mb-0 opacity-75 text-custom-truncate">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum adipisci veritatis consequuntur accusantium, aperiam totam. Quidem suscipit vero veniam quae nulla assumenda iusto, quo officiis eligendi! Nulla itaque reprehenderit voluptatum quibusdam exercitationem, dolor laudantium est odit atque illo illum molestiae quae. Possimus nesciunt rem at placeat repudiandae excepturi quia facere?
                        </p>
                        <img width="40" height="40" class="" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                    </div>
                </div>
                <small class="opacity-50 text-nowrap">24 Jan 2013</small>
            </div>
        </a>


        <!-- pentru primiri cereri in prietenie -->
        <a href="#" class="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
            <div class="rounded-circle">
                <div class="position-relative">
                    <img width="40" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                    <span class="position-absolute notification-badge translate-middle badge rounded-pill bg-primary">
                        <i class="bi bi-person-plus"></i>
                        <span class="visually-hidden">unread messages</span>
                    </span>
                </div>
            </div>
            <div class="d-flex gap-2 w-100 justify-content-between">
                <div>
                    <h6 class="mb-0">Cojocaru Augustin ti-a trimis o cerere de prietenie:</h6>

                    <div class="d-flex gap-2">

                        <p class="mb-0 opacity-75 text-custom-truncate">
                            Aveti 13 prieteni comuni </p>
                    </div>
                </div>
                <small class="opacity-50 text-nowrap">24 Jan 2013</small>
            </div>
        </a>

        <!-- pentru acceptari cereri in prietenie -->
        <a href="#" class="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
            <div class="rounded-circle">
                <div class="position-relative">
                    <img width="40" class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                    <span class="position-absolute notification-badge translate-middle badge rounded-pill bg-primary">
                        <i class="bi bi-person-plus-fill"></i>
                        <span class="visually-hidden">unread messages</span>
                    </span>
                </div>
            </div>
            <div class="d-flex gap-2 w-100 justify-content-between">
                <div>
                    <h6 class="mb-0">Cojocaru Augustin ti-a acceptat cererea de prietenie:</h6>

                    <div class="d-flex gap-2">

                        <p class="mb-0 opacity-75 text-custom-truncate">
                            Felicitari, sunteti acum prieteni!
                        </p>
                    </div>
                </div>
                <small class="opacity-50 text-nowrap">24 Jan 2013</small>
            </div>
        </a>
    </div>

<?php }; ?>