<div class="navbar-left-on-page sticky-top">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist">
        <a class="nav-link" id="list-home-list" href="/StudBud/pages/profile.php">
            <div class="d-flex justify-content-between align-items center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="bi bi-person-circle"></i> Profile
                </div>
            </div>
        </a>
        <a class="nav-link" id="list-profile-list" href="/StudBud/pages/feed.php">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="bi bi-newspaper"></i> Feed
                </div>
                <span class="badge bg-primary rounded-pill">+14</span>
            </div>
        </a>
        <a href="/StudBud/pages/chat.php" class="nav-link" id="list-messages-list">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="fa fa-comments-o" aria-hidden="true"></i> Messages
                </div>
                <span class="badge bg-danger rounded-pill">+14</span>
            </div>
        </a>
        <a href="/StudBud/pages/friends_page.php" class="nav-link" id="list-messages-list">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="fa-solid fa-user-group"></i> Friends
                </div> <span class="badge bg-light text-black rounded-pill">14</span>
            </div>
        </a>
        <a class="nav-link" id="list-messages-list" href="/StudBud/pages/advanced_search.php">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="bi bi-search"></i> Advanced search
                </div>
            </div>
        </a>
        <!-- <a class="nav-link" id="list-settings-list" href="#list-settings">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2 align-items-center">
                    <i class="bi bi-gear-fill"></i> Settings
                </div>
            </div>
        </a> -->
    </div>
    <div class="small yes-log-footer">
        <?php include "/xampp/htdocs/StudBud/components/footer.php" ?>
    </div> 
</div>