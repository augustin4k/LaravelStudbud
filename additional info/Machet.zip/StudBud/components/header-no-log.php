<!-- Navigation-->
<!-- Image and text -->
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <div class="container"> <a class="navbar-brand" href="/StudBud/index.php"> <i class="fa fa-graduation-cap" aria-hidden="true"></i> StudBud </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
            <ul class="navbar-nav">
                <li class="nav-item"> <a class="nav-link" href="/StudBud/contact.php">Contact</a> </li>
                <li class="nav-item"> <a class="nav-link" href="/StudBud/about-us.php">Despre StudBud</a> </li>
                <!-- <li class="nav-item">
                </li> -->
            </ul>
            <a class="ml-lg-2 my-2 my-lg-0 btn btn-outline-primary" href="/StudBud/register.php">Sign up</a>
        </div>
    </div>
</nav>