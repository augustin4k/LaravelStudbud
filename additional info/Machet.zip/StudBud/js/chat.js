$(document).ready(function() {
    // for css of chat
    $(".clearfix .about").css("max-width", "calc(100% - 45px - 1rem");
    $(".clearfix .about").addClass("text-ellipsis");
    $(".chat-list .list-group-item img").addClass("me-1");
    $("body").addClass("overflow-hidden");


    function scrollBtm() {
        $bottom_of_chat = $(".chat_list_messages").outerHeight(true);
        $("#chat_history").scrollTop($bottom_of_chat + $bottom_of_chat);
    };

    function full_screen_chat() {
        var position = $(".chat-app").position();
        var top = position.top;
        var left = position.left;
        $windows_height = $(window).outerHeight();
        $chat_height = $windows_height - top;

        $(".chat-app").height($chat_height);
        $(".chat-app").children().css("height", "calc(100% - 0.25rem)");
        $(".offcanvas-start").height($(".chat-app").height() - 2);

        if ($(window).outerWidth() >= 768) {
            $(".chat-app").children().css("height", "calc(100% - 1rem)");
        }
    };

    full_screen_chat();
    scrollBtm();

    $(window).resize(function() {
        full_screen_chat();
    });
});