window.$(document).ready(function() {


    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function(form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })()
    window.$('[data-toggle="tooltip"]').tooltip();

    window.$(".yes-log-footer").children(".footer").toggleClass("container");

    // pentru colorarea item-urilor de navigare
    window.$location_page = window.$(location).attr("href");

    window.$(".nav-link").each(function(index, element) {
        if (window.$location_page.includes(window.$(this).attr("href"))) {
            console.log(window.$(this));
            window.$(this).toggleClass("active");
        }
    });
    // 

    function resize_windows() {
        window.$(".offcanvas-bottom").css("max-height", "90%");
        window.$(".offcanvas-bottom").css("height", "auto");
        if (window.$(window).width() < 576) {
            // window.$(".container-lg").each(function(index, element) {
            //     if (window.$(this).parent().hasClass("navbar") === false) {
            //         window.$(this).removeClass("container-lg");
            //         window.$(this).addClass("container-sters");
            //         window.$(this).css("padding", "0");
            //     }
            //     window.$(".modal-dialog").each(function(index, element) {
            //         window.$(this).addClass("m-0");
            //     });
            // });
            // window.$(".container").each(function(index, element) {
            //     if (window.$(this).parent().hasClass("navbar") === false) {
            //         window.$(this).toggleClass("container");
            //         window.$(this).toggleClass("container-sters");
            //     }
            //     window.$(".modal-dialog").each(function(index, element) {
            //         window.$(this).addClass("m-0");
            //     });
            // });
        } else {

        }

    };

    resize_windows();
    window.$(window).resize(function() {
        resize_windows();
    });

    window.$(".card").each(function(index, element) {
        window.$(this).addClass("shadow-sm");
    });
    window.$(".navbar").each(function(index, element) {
        window.$(this).addClass("shadow-sm");
    });
    window.$(".accordion").each(function(index, element) {
        window.$(this).addClass("shadow-sm");
    });
    window.$(".dropdown-menu").each(function(index, element) {
        window.$(this).addClass("shadow");
        window.$(this).addClass("p-2");
    });

});