<html> <?php include "/xampp/htdocs/StudBud/components/head.php" ?>
<link rel="stylesheet" href="<?php echo "$base_path" ?>/css/about-us.css">

<body class="bg-light d-flex flex-column"> <?php include "/xampp/htdocs/StudBud/components/header-no-log.php" ?> <header class="p-5 mb-0 bg-primary text-white">
        <div class="container">
            <div></div> <i class="fa fa-graduation-cap fa-4x" aria-hidden="true"></i>
            <h1 class="display-3">Bun venit pe StudBud!</h1>
            <p class="lead">Mai jos iti vom explica ce este StudBud si la ce te ajuta.</p> <a class="btn btn-lg btn-light" href="#about">Sa incepem!</a>
        </div>
    </header>
    <section class="about-section p-5 mb-5" id="about">
        <div class="container">
            <div class="">
                <div class="mb-4">
                    <div class="about-text go-to">
                        <h1 class="display-4">Despre noi</h1>
                        <p class="lead">Aici ai parte de o gama larga de a serviciilor tipice unei retele de socializare. Aici iti poti gasi colegii de facultate, universitate, profesorii, studentii, si chiar si institutia din care faci parte. Puteti comunica, sa va faceti prieteni, sa va schimbati cu posturi interesante si chiar sa lasati recenzii sau sa le cititi cele lasate de altii pentru a-ti usura alegerea. Toate sunt aici! </p>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> 
                                    <i class="fa fa-comments-o fa-2x" aria-hidden="true"></i> 
                                </div>
                                <h6 class="">Chat</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2">
                                    <i class="bi bi-bell-fill fa-2x"></i>
                                </div>
                                <h6 class="">Notificari</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-square-plus fa-2x"></i> </div>
                                <h6 class="">Postari</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-message fa-2x"></i> </div>
                                <h6 class="">Comentarii</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-user-plus fa-2x"></i> </div>
                                <h6 class="">Prieteni</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-magnifying-glass fa-2x"></i> </div>
                                <h6 class="">Cautare</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-star fa-2x"></i> </div>
                                <h6 class="">Recenzii</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-2 mb-4">
                        <div class="card border-hover-primary hover-scale">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2"> <i class="fa-solid fa-heart fa-2x"></i> </div>
                                <h6 class="">Like-uri</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pt-4 border-top border-primary">
                    <div class="counter">
                        <div class="row">
                            <div class="col-6 col-lg-3">
                                <div class="count-data text-center">
                                    <h6 class="count h2 text-dark" data-to="500" data-speed="500">500</h6>
                                    <p class="m-0px font-w-600">Clienti totali</p>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3">
                                <div class="count-data text-center">
                                    <h6 class="count h2 text-success" data-to="150" data-speed="150">150</h6>
                                    <p class="m-0px font-w-600">Clienti online</p>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3">
                                <div class="count-data text-center">
                                    <h6 class="count h2 text-primary" data-to="850" data-speed="850">850</h6>
                                    <p class="m-0px font-w-600">Postari totale</p>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3">
                                <div class="count-data text-center">
                                    <h6 class="count h2 text-danger" data-to="190" data-speed="190">190</h6>
                                    <p class="m-0px font-w-600">Like-uri totale</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> <?php include "/xampp/htdocs/StudBud/components/footer.php" ?>
</body>

</html>